//
//  ViewController.swift
//  SearchBar
//
//

import UIKit
import ContactsUI
import SwiftyJSON

enum SelectedState: String {
    case ACADEMICS
    case NONACADEMICS
}

var contactDetails: [Detail]?
var jsonValue: JValue?

class SearchViewController: UIViewController {
    var selectedState: SelectedState = .ACADEMICS
    var searchedName: [Detail]? = []
    var searching = false

    
    @IBOutlet weak var filter: UIButton!
    @IBOutlet weak var countrySearch: UISearchBar!
    @IBOutlet weak var tblView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        getJsonResponse()
        countrySearch.delegate = self
//        contactDetails = jsonValue?.jvalue?[0].department?[0].detail
        getContactDetails()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        tblView.reloadData()
    }
    
    func getContactDetails(){
        if let jvalue = jsonValue?.jvalue{
            for value in jvalue{
                if let departmentDetail = value.department{
                    for name in departmentDetail{
                        contactDetails = (contactDetails ?? [Detail]()) +  name.detail!
                    }
                }
            }
        }
    }
    
    
    @IBAction func didTapFilterButton(_ sender: UIButton) {
        if let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "FilterViewController") as? FilterViewController {
            if let navigator = navigationController {
                navigator.present(viewController, animated: true, completion: nil)
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func getJsonResponse(){
        if let path = Bundle.main.path(forResource: "faculty", ofType: "json") {
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path), options: .mappedIfSafe)
                let jsonResult = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
                if let jsonResult = jsonResult as? Dictionary<String, AnyObject>{
                    let json = JSON(jsonResult)
                    jsonValue = JValue(json)
                }
            } catch {
                // handle error
            }
        }
    }

}

extension SearchViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching {
            return searchedName?.count ?? 0
        } else {
            return contactDetails?.count ?? 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        if searching {
            cell?.textLabel?.text = searchedName?[indexPath.row].name
        } else {
            cell?.textLabel?.text = contactDetails?[indexPath.row].name
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let cell = tableView.dequeueReusableCell(withIdentifier: "cell"){
            if(searchedName?.count != 0){
                let contactInfo = searchedName?[indexPath.row]
                showContact(name: contactInfo?.name ?? "", mobile: contactInfo?.mobileNumber ?? "", Phone: contactInfo?.PhoneNumber ?? "", email: contactInfo?.emailAddress ?? "")
            }else{
                let contactInfo = contactDetails?[indexPath.row]
                showContact(name: contactInfo?.name ?? "", mobile: contactInfo?.mobileNumber ?? "", Phone: contactInfo?.PhoneNumber ?? "", email: contactInfo?.emailAddress ?? "")
            }
        }
    }
    
    func makeAPhoneCall(number: String)  {
        if let url = URL(string: "tel://\(number)") {
            UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
        }
    }
    
}

extension SearchViewController: UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if let details = contactDetails,searchText != ""{
            searchedName = []
            for value in details {
                if (value.name?.lowercased().contains(searchText.lowercased()))!{
                    searchedName?.append(value)
                }
            }
        }
        searching = true
        tblView.reloadData()
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchedName = []
        searching = false
        searchBar.text = ""
        tblView.reloadData()
    }
}

extension SearchViewController: CNContactViewControllerDelegate{
    func showContact(name: String, mobile: String, Phone: String, email: String){
        let store = CNContactStore()
        let contact = CNMutableContact()
        contact.givenName = name
        let mainNumber = CNLabeledValue(label: CNLabelPhoneNumberMobile, value: CNPhoneNumber(stringValue :mobile ))
        let homePhone = CNLabeledValue(label: CNLabelHome, value: CNPhoneNumber(stringValue :Phone ))
        let workEmail = CNLabeledValue(label:"Work Email", value: email as NSString)
        contact.emailAddresses = [workEmail]
        contact.phoneNumbers = [mainNumber, homePhone]
        let controller = CNContactViewController(forUnknownContact : contact)
        controller.contactStore = store
        controller.delegate = self
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        self.navigationController?.pushViewController(controller, animated: true)
    }
}
