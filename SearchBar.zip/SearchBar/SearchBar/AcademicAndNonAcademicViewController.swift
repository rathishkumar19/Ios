//
//  AcademicAndNonAcademicViewController.swift
//  SearchBar
//
//  Created by Ajithram on 16/03/19.
//

import Foundation
import UIKit

class AcademicAndNonAcademicViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var academicButton: UIButton!
    @IBOutlet weak var nonAcademicButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func didTapAcademicButton(_ sender: UIButton) {
        navigateToContactsScreen(selectedState: SelectedState.ACADEMICS)
    }
    
    @IBAction func didTapNonAcademicButton(_ sender: UIButton) {
        navigateToContactsScreen(selectedState: SelectedState.NONACADEMICS)
    }
    func navigateToContactsScreen(selectedState: SelectedState) {
        if let viewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SearchViewController") as? SearchViewController {
            if let navigator = navigationController {
                viewController.selectedState = selectedState
                navigator.pushViewController(viewController, animated: true)
            }
        }
    }
}
