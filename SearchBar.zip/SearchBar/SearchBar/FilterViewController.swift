//
//  FilterViewController.swift
//  SearchBar
//
//  Created by Ajithram on 24/03/19.
//  Copyright © 2019 SHUBHAM AGARWAL. All rights reserved.
//

import UIKit

var selectedDepartment: String = "CIVIL"

class FilterViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate  {
    
    @IBOutlet weak var departmentLabel: UILabel!
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var dismissButton: UIButton!
    @IBOutlet weak var dropDown: UIPickerView!
    
    var listOfDepartments = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dropDown.delegate = self
        dropDown.dataSource = self
        searchTextField.text = selectedDepartment
        
        if let jvalue = jsonValue?.jvalue{
            for value in jvalue{
                if let departmentDetail = value.department{
                    listOfDepartments = listOfDepartments +  departmentDetail.map({$0.departmentName ?? ""})
                }
            }
        }
        print(listOfDepartments)
    }
    
    @IBAction func dismissButtonPressed(_ sender: UIButton) {
        if let jvalue = jsonValue?.jvalue{
            for value in jvalue{
                if let departmentDetail = value.department{
                    for name in departmentDetail{
                        if name.departmentName == searchTextField.text{
                            contactDetails = name.detail
                        }
                    }
                }
            }
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    public func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1
    }
    
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return listOfDepartments.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        self.view.endEditing(true)
        return listOfDepartments[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.searchTextField.text = self.listOfDepartments[row]
//        self.dropDown.isHidden = true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        if textField == self.searchTextField {
            self.dropDown.isHidden = false
            //if you don't want the users to se the keyboard type:
            
            textField.endEditing(true)
        }
    }
    
}
