//
//  FacultyResponse.swift
//  SearchBar
//
//  Created by Ajithram on 24/03/19.
//

import Foundation
import UIKit
import SwiftyJSON


class JValue: NSObject {
    var jvalue:[FacultyResponse]?
    
    override init() {
        super.init()
    }
    
    public init?(_ json: JSON) {
        super.init()
        jvalue = json["jvalue"].arrayValue.map({FacultyResponse($0)}).compactMap{$0}
    }
}
class FacultyResponse: NSObject {
    var ac: String?
    var department:[Department]?
    
    override init() {
        super.init()
    }
    
    public init?(_ json: JSON) {
        super.init()
        ac = json["ac"].stringValue
        department = json["dept"].arrayValue.map({Department($0)}).compactMap{$0}
    }
}

class Department: NSObject {
    var did: String?
    var departmentName: String?
    var detail: [Detail]?
    
    override init() {
        super.init()
    }
    
    public init?(_ json: JSON){
        super.init()
        did = json["did"].stringValue
        departmentName = json["dc"].stringValue
        detail = json["detail"].arrayValue.map({Detail($0)}).compactMap{$0}
    }
}


class Detail: NSObject{
    var id: String?
    var name: String?
    var desc: String?
    var mobileNumber: String?
    var PhoneNumber: String?
    var emailAddress: String?
    var st: String?
    
    override init() {
        super.init()
    }
    
    public init?(_ json: JSON) {
        super.init()
        id = json["id"].stringValue
        name = json["nm"].stringValue
        desc = json["ds"].stringValue
        mobileNumber = json["mo"].stringValue
        PhoneNumber = json["ph"].stringValue
        emailAddress = json["em"].stringValue
        st = json["st"].stringValue
    }
}
